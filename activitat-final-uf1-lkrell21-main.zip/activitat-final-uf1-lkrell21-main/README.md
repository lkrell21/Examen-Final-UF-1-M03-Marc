# Activitat: p-java-basics-01

### Instruccions

Us heu clonat aquest repositori git en local, i heu de fer aquesta activitat en local.

> **Al final de cada nivell heu de fer un git commit**, amb el missatge:

**Nom cognom: nivell X acabat**

(on X és 1, 2 o 3 segons el cas).

Un cop acabeu, feu un git commit amb el següent missatge, i feu un git push al vostre repositori remot. El missatge ha de ser:

**"Nom Cognom: activitat acabada"**

On nom i cognom són el nom i cognoms de l'alumne.

### Nivells i qualificacions

Hi ha 3 notebooks, un per a cada nivell.

- **Nivell 1**: per arribar al 5

- **Nivell 2**: per arribar al 7.5

- **Nivell 3**: per arribar al 10

Heu d'escriure les respostes als espais indicats a cada notebook.

**TOTES LES RESPOSTES S'HAN D'EXPLICAR I JUSTIFICAR.**

